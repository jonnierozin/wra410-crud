class Tweeet < ApplicationRecord
	belongs_to :user
end
