require "application_system_test_case"

class TweeetsTest < ApplicationSystemTestCase
  # test "visiting the index" do
  #   visit tweeets_url
  #
  #   assert_selector "h1", text: "Tweeet"
  # end
end
